import { useState } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8081";

const getHeaders = () => {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

export default function GestionDetalleVentas() {
  const [detalles, setDetalles] = useState([]);
  const [cargando, setCargando] = useState(false);
  const [creando, setCreando] = useState(false);
  const [error, setError] = useState("");
  const [idVentaBuscar, setIdVentaBuscar] = useState("");
  
  const [form, setForm] = useState({
    ventaId: "",
    productoId: "",
    cantidad: "",
    precioUnitario: "",
  });

  const cargarDetalles = async (idVenta) => {
    if (!idVenta) return;
    setCargando(true);
    setError("");
    try {
      const res = await fetch(`${API}/api/detalle-ventas/venta/${idVenta}`, {
        headers: getHeaders(),
      });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      setDetalles(await res.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
    }
  };

  const handleBuscar = (e) => {
    e.preventDefault();
    cargarDetalles(idVentaBuscar);
  };

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleCrear = async (e) => {
    e.preventDefault();
    setCreando(true);
    setError("");
    try {
      // Mapeo exacto esperado por DetalleVentaController y la Entidad DetalleVenta
      const body = {
        venta: { id: Number(form.ventaId) },
        producto: { idProducto: Number(form.productoId) },
        cantidad: Number(form.cantidad),
        precioUnitario: parseFloat(form.precioUnitario),
      };
      
      const res = await fetch(`${API}/api/detalle-ventas`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(body),
      });
      if (!res.ok) throw new Error(`Error al registrar detalle: ${res.status}`);
      
      setForm({ ventaId: "", productoId: "", cantidad: "", precioUnitario: "" });
      await cargarDetalles(idVentaBuscar || form.ventaId);
    } catch (e) {
      setError(e.message);
    } finally {
      setCreando(false);
    }
  };

  return (
    <div className="min-h-screen bg-[var(--color-fondo)] p-6 font-inherit">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-2xl font-black text-[var(--color-texto)] mb-6 tracking-tight">
          Gestión de Detalles de Venta
        </h1>

        {error && (
          <div className="mb-4 p-3 rounded-lg border border-red-400 bg-red-50 text-red-700 text-sm font-bold">
            {error}
          </div>
        )}

        {/* Buscador */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl p-6 mb-6 shadow-sm">
          <h2 className="text-sm font-bold text-[var(--color-texto)] mb-3 uppercase tracking-wider">
            Buscar Detalles por Venta
          </h2>
          <form onSubmit={handleBuscar} className="flex gap-4">
            <input
              type="number"
              value={idVentaBuscar}
              onChange={(e) => setIdVentaBuscar(e.target.value)}
              placeholder="Ingresa el ID de la venta..."
              required
              className="flex-1 px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]"
            />
            <button
              type="submit"
              className="px-8 py-2.5 rounded-lg bg-[var(--color-primario)] text-white text-sm font-bold hover:bg-[var(--color-primario-dark)] transition-colors shadow-sm"
            >
              Buscar
            </button>
          </form>
        </div>

        {/* Formulario Crear */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl p-6 mb-6 shadow-sm">
          <h2 className="text-sm font-bold text-[var(--color-texto)] mb-4 uppercase tracking-wider">
            Agregar Producto a una Venta
          </h2>
          <form onSubmit={handleCrear} className="grid grid-cols-1 sm:grid-cols-4 gap-4 items-end">
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">ID Venta *</label>
              <input type="number" name="ventaId" value={form.ventaId} onChange={handleChange} required placeholder="Ej. 1"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">ID Producto *</label>
              <input type="number" name="productoId" value={form.productoId} onChange={handleChange} required placeholder="Ej. 5"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Cantidad *</label>
              <input type="number" name="cantidad" value={form.cantidad} onChange={handleChange} required placeholder="Ej. 3"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Precio Unitario *</label>
              <input type="number" step="0.01" name="precioUnitario" value={form.precioUnitario} onChange={handleChange} required placeholder="Ej. 8500.00"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div className="sm:col-span-4 flex justify-end mt-2">
              <button
                type="submit"
                disabled={creando}
                className="px-8 py-2.5 rounded-lg bg-[var(--color-acento)] text-white text-sm font-bold hover:bg-orange-600 disabled:opacity-50 transition-colors shadow-sm"
              >
                {creando ? "Guardando..." : "Agregar Detalle"}
              </button>
            </div>
          </form>
        </div>

        {/* Tabla */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-[var(--color-borde)] bg-[var(--color-fondo)]">
            <h2 className="text-sm font-bold text-[var(--color-texto)] uppercase tracking-wider">
              Detalles de Venta #{idVentaBuscar || "..."}
            </h2>
          </div>
          {cargando ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm animate-pulse">Sincronizando...</div>
          ) : detalles.length === 0 ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm font-bold">
              Busca una venta para ver sus artículos adquiridos.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-[var(--color-secundario-soft)]">
                  <tr>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">ID Detalle</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Venta</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Producto</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Cantidad</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Precio Unit. (Histórico)</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Subtotal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--color-borde)]">
                  {detalles.map((d) => (
                    <tr key={d.id} className="hover:bg-[var(--color-fondo)] transition-colors">
                      <td className="px-5 py-3 font-mono text-gray-500">#{d.id}</td>
                      <td className="px-5 py-3 font-bold text-[var(--color-texto)]">Venta #{d.ventaId}</td>
                      <td className="px-5 py-3 font-bold text-[var(--color-texto)]">Prod. #{d.productoId}</td>
                      <td className="px-5 py-3 text-[var(--color-texto)] font-medium">{d.cantidad}</td>
                      <td className="px-5 py-3 text-[var(--color-texto-suave)]">
                        ${d.precioUnitario != null ? d.precioUnitario.toLocaleString() : "—"}
                      </td>
                      <td className="px-5 py-3 font-black text-[var(--color-acento)]">
                        ${(d.cantidad * d.precioUnitario).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}