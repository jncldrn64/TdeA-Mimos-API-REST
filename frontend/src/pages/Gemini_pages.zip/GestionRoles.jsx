import { useState, useEffect } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8081";

const getHeaders = () => {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

export default function GestionRoles() {
  const [roles, setRoles] = useState([]);
  const [cargando, setCargando] = useState(false);
  const [creando, setCreando] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ nombre: "", descripcion: "" });

  const cargarRoles = async () => {
    setCargando(true);
    setError("");
    try {
      const res = await fetch(`${API}/api/roles`, { headers: getHeaders() });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      setRoles(await res.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
    }
  };

  useEffect(() => { cargarRoles(); }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleCrear = async (e) => {
    e.preventDefault();
    setCreando(true);
    setError("");
    try {
      const res = await fetch(`${API}/api/roles`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      setForm({ nombre: "", descripcion: "" });
      await cargarRoles();
    } catch (e) {
      setError(e.message);
    } finally {
      setCreando(false);
    }
  };

  const handleEliminar = async (idRol) => {
    if (!window.confirm(`¿Eliminar rol #${idRol}?`)) return;
    setError("");
    try {
      const res = await fetch(`${API}/api/roles/${idRol}`, {
        method: "DELETE",
        headers: getHeaders(),
      });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      await cargarRoles();
    } catch (e) {
      setError(e.message);
    }
  };

  return (
    <div className="min-h-screen bg-[var(--color-fondo)] p-6 font-inherit">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-2xl font-black text-[var(--color-texto)] mb-6 tracking-tight">
          Gestión de Roles
        </h1>

        {error && (
          <div className="mb-4 p-3 rounded-lg border border-red-400 bg-red-50 text-red-700 text-sm font-bold">
            {error}
          </div>
        )}

        {/* Formulario */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl p-5 mb-6 shadow-sm">
          <h2 className="text-sm font-bold text-[var(--color-texto)] mb-4 uppercase tracking-wider">Nuevo Rol</h2>
          <form onSubmit={handleCrear} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Nombre *</label>
              <input type="text" name="nombre" value={form.nombre} onChange={handleChange} required placeholder="Ej. ADMIN"
                className="w-full px-3 py-2 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Descripción</label>
              <input type="text" name="descripcion" value={form.descripcion} onChange={handleChange} placeholder="Descripción del rol"
                className="w-full px-3 py-2 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div className="sm:col-span-2 flex justify-end">
              <button type="submit" disabled={creando}
                className="px-6 py-2.5 rounded-lg bg-[var(--color-acento)] text-white text-sm font-bold hover:bg-orange-600 disabled:opacity-50 transition-colors shadow-sm">
                {creando ? "Creando..." : "Crear Rol"}
              </button>
            </div>
          </form>
        </div>

        {/* Tabla */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-[var(--color-borde)] bg-[var(--color-fondo)]">
            <h2 className="text-sm font-bold text-[var(--color-texto)] uppercase tracking-wider">Roles del Sistema</h2>
          </div>
          {cargando ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm animate-pulse">Sincronizando base de datos...</div>
          ) : roles.length === 0 ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm font-bold">No hay roles registrados.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-[var(--color-secundario-soft)]">
                  <tr>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">ID</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Nombre</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Descripción</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase text-center">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--color-borde)]">
                  {roles.map((r) => (
                    <tr key={r.idRol} className="hover:bg-[var(--color-fondo)] transition-colors">
                      <td className="px-5 py-3 font-mono text-gray-500">#{r.idRol}</td>
                      <td className="px-5 py-3">
                        <span className="px-2 py-1 rounded-md text-xs font-black bg-[var(--color-secundario-soft)] text-[var(--color-acento)]">
                          {r.nombre}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-[var(--color-texto-suave)]">{r.descripcion ?? "—"}</td>
                      <td className="px-5 py-3 text-center">
                        <button onClick={() => handleEliminar(r.idRol)}
                          className="px-3 py-1 rounded-lg border border-red-300 text-red-600 text-xs font-bold hover:bg-red-50 transition-colors">
                          Eliminar
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}