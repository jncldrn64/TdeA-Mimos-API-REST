import { useState, useEffect } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8081";

const getHeaders = () => {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

export default function GestionCarritos() {
  const [carritos, setCarritos] = useState([]);
  const [cargando, setCargando] = useState(false);
  const [creando, setCreando] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ usuarioId: "" });

  const cargarCarritos = async () => {
    setCargando(true);
    setError("");
    try {
      const res = await fetch(`${API}/api/carritos`, { headers: getHeaders() });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      setCarritos(await res.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
    }
  };

  useEffect(() => { cargarCarritos(); }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleCrear = async (e) => {
    e.preventDefault();
    setCreando(true);
    setError("");
    try {
      // El controlador espera la entidad Carrito, mapeamos la relación con Usuario
      const body = { usuario: { idUsuario: Number(form.usuarioId) } };
      
      const res = await fetch(`${API}/api/carritos`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(body),
      });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      setForm({ usuarioId: "" });
      await cargarCarritos();
    } catch (e) {
      setError(e.message);
    } finally {
      setCreando(false);
    }
  };

  const handleEliminar = async (idCarrito) => {
    if (!window.confirm(`¿Estás seguro de eliminar el carrito #${idCarrito}?`)) return;
    setError("");
    try {
      const res = await fetch(`${API}/api/carritos/${idCarrito}`, {
        method: "DELETE",
        headers: getHeaders(),
      });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      await cargarCarritos();
    } catch (e) {
      setError(e.message);
    }
  };

  return (
    <div className="min-h-screen bg-[var(--color-fondo)] p-6 font-inherit">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-black text-[var(--color-texto)] mb-6 tracking-tight">
          Gestión de Carritos
        </h1>

        {error && (
          <div className="mb-4 p-3 rounded-lg border border-red-400 bg-red-50 text-red-700 text-sm font-bold">
            {error}
          </div>
        )}

        {/* Formulario Crear */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl p-6 mb-6 shadow-sm">
          <h2 className="text-sm font-bold text-[var(--color-texto)] mb-4 uppercase tracking-wider">
            Nuevo Carrito
          </h2>
          <form onSubmit={handleCrear} className="flex flex-col sm:flex-row gap-4 items-end">
            <div className="flex-1 w-full">
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">
                ID de Usuario *
              </label>
              <input
                type="number"
                name="usuarioId"
                value={form.usuarioId}
                onChange={handleChange}
                required
                placeholder="Ej. 1"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]"
              />
            </div>
            <div className="w-full sm:w-auto">
              <button
                type="submit"
                disabled={creando}
                className="w-full sm:w-auto px-8 py-2.5 rounded-lg bg-[var(--color-acento)] text-white text-sm font-bold hover:bg-orange-600 disabled:opacity-50 transition-colors shadow-sm"
              >
                {creando ? "Creando..." : "Crear Carrito"}
              </button>
            </div>
          </form>
        </div>

        {/* Tabla */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-[var(--color-borde)] bg-[var(--color-fondo)]">
            <h2 className="text-sm font-bold text-[var(--color-texto)] uppercase tracking-wider">
              Carritos Registrados
            </h2>
          </div>
          {cargando ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm animate-pulse">
              Sincronizando base de datos...
            </div>
          ) : carritos.length === 0 ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm font-bold">
              No hay carritos registrados.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-[var(--color-secundario-soft)]">
                  <tr>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">ID Carrito</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">ID Usuario</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Fecha Creación</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase text-center">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--color-borde)]">
                  {carritos.map((c) => (
                    <tr key={c.idCarrito} className="hover:bg-[var(--color-fondo)] transition-colors">
                      <td className="px-5 py-3 text-gray-500 font-mono">#{c.idCarrito}</td>
                      <td className="px-5 py-3 font-bold text-[var(--color-texto)]">Usuario #{c.usuarioId}</td>
                      <td className="px-5 py-3 text-[var(--color-texto-suave)] font-medium">
                        {c.creadoAt ? new Date(c.creadoAt).toLocaleString() : "—"}
                      </td>
                      <td className="px-5 py-3 text-center">
                        <button
                          onClick={() => handleEliminar(c.idCarrito)}
                          className="px-3 py-1 rounded-lg border border-red-300 text-red-600 text-xs font-bold hover:bg-red-50 transition-colors"
                        >
                          Eliminar
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}