import { useState, useEffect } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8081";

const getHeaders = () => {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

export default function GestionProductos() {
  const [productos, setProductos] = useState([]);
  const [listaCategorias, setListaCategorias] = useState([]); // Para poblar los <select>
  const [cargando, setCargando] = useState(false);
  const [creando, setCreando] = useState(false);
  const [error, setError] = useState("");
  const [soloActivos, setSoloActivos] = useState(false);
  
  const [form, setForm] = useState({
    nombreProducto: "", descripcionDetallada: "", precioUnitario: "", stockDisponible: "", urlImagen: "", idCategoria: "", fechaUltimoRestock: "",
  });

  // Modal de edición
  const [modalEdicion, setModalEdicion] = useState(null);
  const [actualizando, setActualizando] = useState(false);

  const cargarDatos = async (activos = false) => {
    setCargando(true);
    setError("");
    try {
      const urlProd = activos ? `${API}/api/productos/activos` : `${API}/api/productos`;
      // Traemos productos y categorías al mismo tiempo
      const [resProd, resCat] = await Promise.all([
        fetch(urlProd, { headers: getHeaders() }),
        fetch(`${API}/api/categorias`, { headers: getHeaders() })
      ]);
      
      if (!resProd.ok) throw new Error(`Error Productos: ${resProd.status}`);
      if (!resCat.ok) throw new Error(`Error Categorías: ${resCat.status}`);
      
      setProductos(await resProd.json());
      setListaCategorias(await resCat.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
    }
  };

  useEffect(() => { cargarDatos(false); }, []);

  const handleFiltro = (e) => {
    setSoloActivos(e.target.checked);
    cargarDatos(e.target.checked);
  };

  // ── POST (Crear) ──
  const handleCrear = async (e) => {
    e.preventDefault();
    setCreando(true);
    setError("");
    try {
      const body = {
        nombreProducto: form.nombreProducto,
        descripcionDetallada: form.descripcionDetallada || null,
        precioUnitario: parseFloat(form.precioUnitario),
        stockDisponible: Number(form.stockDisponible),
        urlImagen: form.urlImagen || null,
        idCategoria: form.idCategoria ? Number(form.idCategoria) : null,
        fechaUltimoRestock: form.fechaUltimoRestock || null,
      };
      const res = await fetch(`${API}/api/productos`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(body),
      });
      if (!res.ok) throw new Error(`Error: ${await res.text()}`);
      
      setForm({ nombreProducto: "", descripcionDetallada: "", precioUnitario: "", stockDisponible: "", urlImagen: "", idCategoria: "", fechaUltimoRestock: "" });
      await cargarDatos(soloActivos);
    } catch (e) { setError(e.message); } finally { setCreando(false); }
  };

  // ── MÉTODOS PARA EL MODAL (Edición) ──
  const abrirEdicion = (prod) => {
    // El backend (ProductoDTO) nos devuelve la categoría como nombre (String), no el ID.
    // Buscamos el ID en la lista de categorías para preseleccionar el <select>
    const catEncontrada = listaCategorias.find(c => c.nombre === prod.categoria);
    
    setModalEdicion({
      ...prod,
      idCategoria: catEncontrada ? catEncontrada.idCategoria : "",
      // Si la fecha existe, le quitamos la hora (T00:00:00) para el input type="date"
      fechaUltimoRestock: prod.fechaUltimoRestock ? prod.fechaUltimoRestock.split('T')[0] : ""
    });
  };

  const handleActualizar = async (e) => {
    e.preventDefault();
    setActualizando(true);
    try {
      const body = {
        nombreProducto: modalEdicion.nombreProducto,
        descripcionDetallada: modalEdicion.descripcionDetallada || null,
        precioUnitario: parseFloat(modalEdicion.precioUnitario),
        stockDisponible: Number(modalEdicion.stockDisponible),
        urlImagen: modalEdicion.urlImagen || null,
        idCategoria: modalEdicion.idCategoria ? Number(modalEdicion.idCategoria) : null,
        fechaUltimoRestock: modalEdicion.fechaUltimoRestock || null,
      };

      const res = await fetch(`${API}/api/productos/${modalEdicion.idProducto}`, {
        method: "PUT",
        headers: getHeaders(),
        body: JSON.stringify(body),
      });
      
      if (!res.ok) throw new Error(await res.text());
      setModalEdicion(null);
      await cargarDatos(soloActivos);
    } catch (e) { alert(e.message); } finally { setActualizando(false); }
  };

  // ── DELETE ──
  const handleEliminar = async (id) => {
    if (!window.confirm(`¿Eliminar producto #${id}?`)) return;
    setError("");
    try {
      const res = await fetch(`${API}/api/productos/${id}`, { method: "DELETE", headers: getHeaders() });
      if (!res.ok) throw new Error(`Error al borrar: ${res.status}`);
      await cargarDatos(soloActivos);
    } catch (e) { setError(e.message); }
  };

  return (
    <div className="min-h-screen bg-[var(--color-fondo)] p-6 font-inherit">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl font-black text-[var(--color-texto)] mb-6 tracking-tight">Gestión de Productos</h1>

        {error && <div className="mb-4 p-3 rounded-lg border border-red-400 bg-red-50 text-red-700 text-sm font-bold">{error}</div>}

        {/* Formulario Crear */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl p-6 mb-6 shadow-sm">
          <h2 className="text-sm font-bold text-[var(--color-texto)] mb-4 uppercase tracking-wider">Nuevo Producto</h2>
          <form onSubmit={handleCrear} className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Nombre *</label>
              <input type="text" required value={form.nombreProducto} onChange={e=>setForm({...form, nombreProducto: e.target.value})} placeholder="Helado de fresa"
                className="w-full px-3 py-2 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Categoría</label>
              <select value={form.idCategoria} onChange={e=>setForm({...form, idCategoria: e.target.value})} 
                className="w-full px-3 py-2 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]">
                <option value="">Ninguna</option>
                {listaCategorias.map(c => <option key={c.idCategoria} value={c.idCategoria}>{c.nombre}</option>)}
              </select>
            </div>
            <div className="md:col-span-3">
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Descripción</label>
              <textarea value={form.descripcionDetallada} onChange={e=>setForm({...form, descripcionDetallada: e.target.value})} rows={2} placeholder="Helado artesanal..."
                className="w-full px-3 py-2 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)] resize-none" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Precio Unitario *</label>
              <input type="number" step="0.01" required value={form.precioUnitario} onChange={e=>setForm({...form, precioUnitario: e.target.value})} placeholder="8500.00"
                className="w-full px-3 py-2 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Stock Inicial *</label>
              <input type="number" required value={form.stockDisponible} onChange={e=>setForm({...form, stockDisponible: e.target.value})} placeholder="50"
                className="w-full px-3 py-2 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">URL Imagen</label>
              <input type="url" value={form.urlImagen} onChange={e=>setForm({...form, urlImagen: e.target.value})} placeholder="https://..."
                className="w-full px-3 py-2 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div className="md:col-span-3 flex justify-end pt-2">
              <button type="submit" disabled={creando}
                className="px-8 py-2.5 rounded-lg bg-[var(--color-acento)] text-white text-sm font-bold hover:bg-orange-600 disabled:opacity-50 transition-colors shadow-sm">
                {creando ? "Creando..." : "Crear Producto"}
              </button>
            </div>
          </form>
        </div>

        {/* Tabla */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-[var(--color-borde)] bg-[var(--color-fondo)] flex items-center justify-between gap-4 flex-wrap">
            <h2 className="text-sm font-bold text-[var(--color-texto)] uppercase tracking-wider">Inventario</h2>
            <label className="flex items-center gap-2 text-xs font-bold text-[var(--color-texto-suave)] cursor-pointer bg-white px-3 py-1.5 rounded border border-[var(--color-borde)] shadow-sm">
              <input type="checkbox" checked={soloActivos} onChange={handleFiltro} className="accent-[var(--color-acento)]" />
              Ver Solo Activos (Catálogo Público)
            </label>
          </div>
          
          {cargando ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm animate-pulse">Sincronizando bodega...</div>
          ) : productos.length === 0 ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm font-bold">No hay productos.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-[var(--color-secundario-soft)]">
                  <tr>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Img</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">ID</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Nombre</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Categoría</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Precio</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Stock</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Visible</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase text-center">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--color-borde)]">
                  {productos.map((p) => (
                    <tr key={p.idProducto} className="hover:bg-[var(--color-fondo)] transition-colors">
                      <td className="px-5 py-2">
                        <img src={p.urlImagen || "/img/productos/default.png"} className="w-8 h-8 object-contain bg-white rounded border border-[var(--color-borde)]" onError={(e)=>e.target.style.display='none'}/>
                      </td>
                      <td className="px-5 py-3 font-mono text-gray-500">#{p.idProducto}</td>
                      <td className="px-5 py-3 font-bold text-[var(--color-texto)]">{p.nombreProducto}</td>
                      <td className="px-5 py-3 text-[var(--color-texto-suave)] font-medium">
                        {p.categoria ? <span className="bg-gray-100 px-2 py-1 rounded border border-gray-200 text-xs">{p.categoria}</span> : "—"}
                      </td>
                      <td className="px-5 py-3 text-[var(--color-acento)] font-black">
                        ${Number(p.precioUnitario).toLocaleString()}
                      </td>
                      <td className="px-5 py-3">
                        <span className={`px-2 py-1 rounded font-bold text-xs ${p.stockDisponible > 10 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                          {p.stockDisponible} u.
                        </span>
                      </td>
                      <td className="px-5 py-3">
                        <span className={`px-2 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${p.estaActivo ? "bg-[var(--color-secundario)] text-[var(--color-primario-dark)]" : "bg-gray-200 text-gray-500"}`}>
                          {p.estaActivo ? "SÍ" : "NO"}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-center">
                        <button onClick={() => abrirEdicion(p)} className="text-[var(--color-acento)] hover:text-orange-700 font-bold text-xs mr-4 hover:underline">Editar</button>
                        <button onClick={() => handleEliminar(p.idProducto)} className="text-red-500 hover:text-red-700 font-bold text-xs hover:underline">Eliminar</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* ── MODAL FLOTANTE DE EDICIÓN ── */}
        {modalEdicion && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-200">
             <div className="bg-[var(--color-superficie)] w-full max-w-2xl rounded-2xl shadow-2xl p-6 border border-[var(--color-borde)] max-h-[90vh] overflow-y-auto">
                <h3 className="text-xl font-black mb-6 border-b border-[var(--color-borde)] pb-3 text-[var(--color-texto)]">
                  Modificar Producto #{modalEdicion.idProducto}
                </h3>
                <form onSubmit={handleActualizar} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Nombre *</label>
                    <input type="text" required value={modalEdicion.nombreProducto} onChange={e=>setModalEdicion({...modalEdicion, nombreProducto: e.target.value})}
                      className="w-full p-2.5 border border-[var(--color-borde)] rounded-lg bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Precio Unitario *</label>
                    <input type="number" step="0.01" required value={modalEdicion.precioUnitario} onChange={e=>setModalEdicion({...modalEdicion, precioUnitario: e.target.value})}
                      className="w-full p-2.5 border border-[var(--color-borde)] rounded-lg bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Stock Disponible *</label>
                    <input type="number" required value={modalEdicion.stockDisponible} onChange={e=>setModalEdicion({...modalEdicion, stockDisponible: e.target.value})}
                      className="w-full p-2.5 border border-[var(--color-borde)] rounded-lg bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Categoría</label>
                    <select value={modalEdicion.idCategoria} onChange={e=>setModalEdicion({...modalEdicion, idCategoria: e.target.value})} 
                      className="w-full p-2.5 border border-[var(--color-borde)] rounded-lg bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]">
                      <option value="">Ninguna</option>
                      {listaCategorias.map(c => <option key={c.idCategoria} value={c.idCategoria}>{c.nombre}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Fecha de Restock</label>
                    <input type="date" value={modalEdicion.fechaUltimoRestock || ""} onChange={e=>setModalEdicion({...modalEdicion, fechaUltimoRestock: e.target.value})}
                      className="w-full p-2.5 border border-[var(--color-borde)] rounded-lg bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">URL Imagen</label>
                    <input type="url" value={modalEdicion.urlImagen} onChange={e=>setModalEdicion({...modalEdicion, urlImagen: e.target.value})}
                      className="w-full p-2.5 border border-[var(--color-borde)] rounded-lg bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Descripción Detallada</label>
                    <textarea rows="3" value={modalEdicion.descripcionDetallada} onChange={e=>setModalEdicion({...modalEdicion, descripcionDetallada: e.target.value})}
                      className="w-full p-2.5 border border-[var(--color-borde)] rounded-lg bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)] resize-none" />
                  </div>
                  
                  <div className="sm:col-span-2 flex gap-3 mt-4 pt-4 border-t border-[var(--color-borde)]">
                    <button type="button" onClick={() => setModalEdicion(null)} className="flex-1 bg-[var(--color-fondo)] border border-[var(--color-borde)] text-[var(--color-texto-suave)] font-bold py-3 rounded-lg hover:bg-gray-100 transition-colors">Cancelar</button>
                    <button type="submit" disabled={actualizando} className="flex-1 bg-[var(--color-acento)] text-white font-bold py-3 rounded-lg hover:bg-orange-600 disabled:opacity-50 transition-colors shadow-sm">
                      {actualizando ? "Guardando..." : "Guardar Cambios"}
                    </button>
                  </div>
                </form>
             </div>
          </div>
        )}

      </div>
    </div>
  );
}