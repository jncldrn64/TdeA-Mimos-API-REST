import { useState, useEffect } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8081";

const getHeaders = () => {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

export default function GestionVentas() {
  const [ventas, setVentas] = useState([]);
  const [cargando, setCargando] = useState(false);
  const [creando, setCreando] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    compradorId: "",
    cedulaComprador: "",
    metodoPago: "",
    total: "",
  });

  const cargarVentas = async () => {
    setCargando(true);
    setError("");
    try {
      const res = await fetch(`${API}/api/ventas`, { headers: getHeaders() });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      setVentas(await res.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
    }
  };

  useEffect(() => { cargarVentas(); }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleCrear = async (e) => {
    e.preventDefault();
    setCreando(true);
    setError("");
    try {
      // Mapeo exacto esperado por VentaController y la Entidad Venta
      const body = {
        comprador: { idUsuario: Number(form.compradorId) },
        cedulaComprador: form.cedulaComprador,
        metodoPago: form.metodoPago,
        total: parseFloat(form.total),
      };
      
      const res = await fetch(`${API}/api/ventas`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(body),
      });
      
      if (!res.ok) throw new Error(`Error al crear: ${res.status}`);
      setForm({ compradorId: "", cedulaComprador: "", metodoPago: "", total: "" });
      await cargarVentas();
    } catch (e) {
      setError(e.message);
    } finally {
      setCreando(false);
    }
  };

  const estadoBadge = (estado) => {
    const map = {
      pendiente: "bg-yellow-100 text-yellow-700",
      completado: "bg-green-100 text-green-700",
      cancelado: "bg-red-100 text-red-700",
    };
    return map[estado?.toLowerCase()] ?? "bg-[var(--color-secundario-soft)] text-[var(--color-acento)]";
  };

  return (
    <div className="min-h-screen bg-[var(--color-fondo)] p-6 font-inherit">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-2xl font-black text-[var(--color-texto)] mb-6 tracking-tight">
          Gestión de Ventas
        </h1>

        {error && (
          <div className="mb-4 p-3 rounded-lg border border-red-400 bg-red-50 text-red-700 text-sm font-bold">
            {error}
          </div>
        )}

        {/* Formulario */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl p-6 mb-6 shadow-sm">
          <h2 className="text-sm font-bold text-[var(--color-texto)] mb-4 uppercase tracking-wider">Registrar Nueva Venta (Manual)</h2>
          <form onSubmit={handleCrear} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">ID Comprador *</label>
              <input type="number" name="compradorId" value={form.compradorId} onChange={handleChange} required placeholder="Ej. 1"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Cédula Comprador</label>
              <input type="text" name="cedulaComprador" value={form.cedulaComprador} onChange={handleChange} placeholder="Ej. 12345678"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Método de Pago</label>
              <select name="metodoPago" value={form.metodoPago} onChange={handleChange} required
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]">
                <option value="">Seleccionar...</option>
                <option value="Efectivo">Efectivo</option>
                <option value="Tarjeta">Tarjeta</option>
                <option value="Transferencia">Transferencia</option>
                <option value="Wompi">Wompi</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Total Venta *</label>
              <input type="number" step="0.01" name="total" value={form.total} onChange={handleChange} required placeholder="Ej. 45000.00"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div className="sm:col-span-2 lg:col-span-4 flex justify-end mt-2">
              <button type="submit" disabled={creando}
                className="px-8 py-2.5 rounded-lg bg-[var(--color-acento)] text-white text-sm font-bold hover:bg-orange-600 disabled:opacity-50 transition-colors shadow-sm">
                {creando ? "Registrando..." : "Registrar Venta"}
              </button>
            </div>
          </form>
        </div>

        {/* Tabla */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-[var(--color-borde)] bg-[var(--color-fondo)]">
            <h2 className="text-sm font-bold text-[var(--color-texto)] uppercase tracking-wider">Historial de Facturación</h2>
          </div>
          {cargando ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm animate-pulse">Sincronizando registros financieros...</div>
          ) : ventas.length === 0 ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm font-bold">No hay ventas registradas.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-[var(--color-secundario-soft)]">
                  <tr>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">ID Venta</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">ID Comprador</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Cédula</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Fecha</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Método Pago</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Total</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Estado</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--color-borde)]">
                  {ventas.map((v) => (
                    <tr key={v.id} className="hover:bg-[var(--color-fondo)] transition-colors">
                      <td className="px-5 py-3 font-mono text-gray-500">#{v.id}</td>
                      <td className="px-5 py-3 font-bold text-[var(--color-texto)]">Usuario #{v.compradorId}</td>
                      <td className="px-5 py-3 text-[var(--color-texto-suave)]">{v.cedulaComprador ?? "—"}</td>
                      <td className="px-5 py-3 text-[var(--color-texto-suave)] font-medium">
                        {v.fecha ? new Date(v.fecha).toLocaleString() : "—"}
                      </td>
                      <td className="px-5 py-3 text-[var(--color-texto)] font-medium">{v.metodoPago ?? "—"}</td>
                      <td className="px-5 py-3 font-black text-[var(--color-acento)]">
                        {v.total != null ? `$${v.total.toLocaleString()}` : "—"}
                      </td>
                      <td className="px-5 py-3">
                        <span className={`px-2 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${estadoBadge(v.estado)}`}>
                          {v.estado ?? "—"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <p className="mt-4 text-xs text-[var(--color-texto-suave)] text-center font-bold">
          <span className="text-red-500">*</span> Por políticas de auditoría, las ventas registradas no pueden ser eliminadas.
        </p>
      </div>
    </div>
  );
}