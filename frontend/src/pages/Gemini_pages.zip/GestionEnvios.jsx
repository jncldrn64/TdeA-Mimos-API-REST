import { useState, useEffect } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8081";

const getHeaders = () => {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

const ESTADOS = ["preparando", "despachado", "entregado", "cancelado"];

export default function GestionEnvios() {
  const [envios, setEnvios] = useState([]);
  const [cargando, setCargando] = useState(false);
  const [creando, setCreando] = useState(false);
  const [error, setError] = useState("");
  const [filtroEstado, setFiltroEstado] = useState("");
  const [form, setForm] = useState({
    ventaId: "",
    direccion: "",
    ciudad: "",
    fechaEntregaEstimada: "",
  });

  const cargarEnvios = async (estado = "") => {
    setCargando(true);
    setError("");
    try {
      const url = estado
        ? `${API}/api/envios/estado/${estado}`
        : `${API}/api/envios`;
      const res = await fetch(url, { headers: getHeaders() });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      setEnvios(await res.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
    }
  };

  useEffect(() => { cargarEnvios(); }, []);

  const handleFiltro = (e) => {
    const val = e.target.value;
    setFiltroEstado(val);
    cargarEnvios(val);
  };

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleCrear = async (e) => {
    e.preventDefault();
    setCreando(true);
    setError("");
    try {
      // Mapeo exacto esperado por CrearEnvioDTO
      const body = {
        ventaId: Number(form.ventaId),
        direccion: form.direccion,
        ciudad: form.ciudad,
        fechaEntregaEstimada: form.fechaEntregaEstimada || null,
      };
      
      const res = await fetch(`${API}/api/envios`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(body),
      });
      
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || `Error ${res.status}`);
      }
      
      setForm({ ventaId: "", direccion: "", ciudad: "", fechaEntregaEstimada: "" });
      await cargarEnvios(filtroEstado);
    } catch (e) {
      setError(e.message);
    } finally {
      setCreando(false);
    }
  };

  const handleEliminar = async (idEnvio) => {
    if (!window.confirm(`¿Eliminar envío #${idEnvio}?`)) return;
    setError("");
    try {
      const res = await fetch(`${API}/api/envios/${idEnvio}`, {
        method: "DELETE",
        headers: getHeaders(),
      });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      await cargarEnvios(filtroEstado);
    } catch (e) {
      setError(e.message);
    }
  };

  const estadoBadge = (estado) => {
    const map = {
      preparando: "bg-yellow-100 text-yellow-700",
      despachado: "bg-blue-100 text-blue-700",
      entregado: "bg-green-100 text-green-700",
      cancelado: "bg-red-100 text-red-700",
    };
    return map[estado?.toLowerCase()] ?? "bg-[var(--color-secundario-soft)] text-[var(--color-acento)]";
  };

  return (
    <div className="min-h-screen bg-[var(--color-fondo)] p-6 font-inherit">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-2xl font-black text-[var(--color-texto)] mb-6 tracking-tight">
          Gestión de Envíos
        </h1>

        {error && (
          <div className="mb-4 p-3 rounded-lg border border-red-400 bg-red-50 text-red-700 text-sm font-bold">
            {error}
          </div>
        )}

        {/* Formulario Crear */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl p-6 mb-6 shadow-sm">
          <h2 className="text-sm font-bold text-[var(--color-texto)] mb-4 uppercase tracking-wider">
            Registrar Nuevo Envío
          </h2>
          <form onSubmit={handleCrear} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">ID Venta *</label>
              <input type="number" name="ventaId" value={form.ventaId} onChange={handleChange} required placeholder="Ej. 1"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Ciudad *</label>
              <input type="text" name="ciudad" value={form.ciudad} onChange={handleChange} required placeholder="Medellín"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Fecha Entrega Est.</label>
              <input type="date" name="fechaEntregaEstimada" value={form.fechaEntregaEstimada} onChange={handleChange}
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div className="sm:col-span-2 lg:col-span-4">
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Dirección Completa *</label>
              <input type="text" name="direccion" value={form.direccion} onChange={handleChange} required placeholder="Calle 50 # 10-20"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div className="sm:col-span-2 lg:col-span-4 flex justify-end mt-2">
              <button type="submit" disabled={creando}
                className="px-8 py-2.5 rounded-lg bg-[var(--color-acento)] text-white text-sm font-bold hover:bg-orange-600 disabled:opacity-50 transition-colors shadow-sm">
                {creando ? "Creando..." : "Crear Envío"}
              </button>
            </div>
          </form>
        </div>

        {/* Filtro + Tabla */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-[var(--color-borde)] bg-[var(--color-fondo)] flex items-center justify-between gap-4 flex-wrap">
            <h2 className="text-sm font-bold text-[var(--color-texto)] uppercase tracking-wider">Historial Logístico</h2>
            <select value={filtroEstado} onChange={handleFiltro}
              className="px-3 py-1.5 rounded-lg border border-[var(--color-borde)] bg-white text-[var(--color-texto)] text-sm font-bold focus:outline-none focus:border-[var(--color-acento)] shadow-sm cursor-pointer">
              <option value="">Todos los estados</option>
              {ESTADOS.map((e) => <option key={e} value={e}>{e}</option>)}
            </select>
          </div>
          {cargando ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm animate-pulse">Sincronizando operaciones...</div>
          ) : envios.length === 0 ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm font-bold">No hay envíos registrados.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-[var(--color-secundario-soft)]">
                  <tr>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">ID</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Venta</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Dirección</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Ciudad</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Estado</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Fechas (Est. / Real)</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase text-center">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--color-borde)]">
                  {envios.map((env) => (
                    <tr key={env.idEnvio} className="hover:bg-[var(--color-fondo)] transition-colors">
                      <td className="px-5 py-3 font-mono text-gray-500">#{env.idEnvio}</td>
                      <td className="px-5 py-3 font-bold text-[var(--color-texto)]">Venta #{env.ventaId}</td>
                      <td className="px-5 py-3 text-[var(--color-texto)]">{env.direccion}</td>
                      <td className="px-5 py-3 text-[var(--color-texto-suave)] font-medium">{env.ciudad}</td>
                      <td className="px-5 py-3">
                        <span className={`px-2 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${estadoBadge(env.estadoEnvio)}`}>
                          {env.estadoEnvio ?? "—"}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-xs text-[var(--color-texto-suave)]">
                        Est: {env.fechaEntregaEstimada ? new Date(env.fechaEntregaEstimada).toLocaleDateString() : "—"}<br/>
                        Real: <span className="font-bold">{env.fechaEntregaReal ? new Date(env.fechaEntregaReal).toLocaleDateString() : "—"}</span>
                      </td>
                      <td className="px-5 py-3 text-center">
                        <button onClick={() => handleEliminar(env.idEnvio)}
                          className="px-3 py-1 rounded-lg border border-red-300 text-red-600 text-xs font-bold hover:bg-red-50 transition-colors">
                          Eliminar
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}