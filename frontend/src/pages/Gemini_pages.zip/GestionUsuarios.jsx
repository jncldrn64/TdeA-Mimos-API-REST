import { useState, useEffect } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8081";

const getHeaders = () => {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

export default function GestionUsuarios() {
  const [usuarios, setUsuarios] = useState([]);
  const [cargando, setCargando] = useState(false);
  const [creando, setCreando] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    nombre: "",
    apellido: "",
    email: "",
    password: "",
    idRol: "",
  });

  const cargarUsuarios = async () => {
    setCargando(true);
    setError("");
    try {
      const res = await fetch(`${API}/api/usuarios`, { headers: getHeaders() });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      setUsuarios(await res.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
    }
  };

  useEffect(() => { cargarUsuarios(); }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleCrear = async (e) => {
    e.preventDefault();
    setCreando(true);
    setError("");
    try {
      const body = {
        nombre: form.nombre,
        apellido: form.apellido,
        email: form.email,
        password: form.password,
        idRol: Number(form.idRol),
      };
      const res = await fetch(`${API}/api/usuarios`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || `Error ${res.status}`);
      }
      setForm({ nombre: "", apellido: "", email: "", password: "", idRol: "" });
      await cargarUsuarios();
    } catch (e) {
      setError(e.message);
    } finally {
      setCreando(false);
    }
  };

  const handleEliminar = async (idUsuario) => {
    if (!window.confirm(`¿Eliminar usuario #${idUsuario}?`)) return;
    setError("");
    try {
      const res = await fetch(`${API}/api/usuarios/${idUsuario}`, {
        method: "DELETE",
        headers: getHeaders(),
      });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      await cargarUsuarios();
    } catch (e) {
      setError(e.message);
    }
  };

  return (
    <div className="min-h-screen bg-[var(--color-fondo)] p-6 font-inherit">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl font-black text-[var(--color-texto)] mb-6 tracking-tight">
          Gestión de Usuarios
        </h1>

        {error && (
          <div className="mb-4 p-3 rounded-lg border border-red-400 bg-red-50 text-red-700 text-sm font-bold">
            {error}
          </div>
        )}

        {/* Formulario */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl p-6 mb-6 shadow-sm">
          <h2 className="text-sm font-bold text-[var(--color-texto)] mb-4 uppercase tracking-wider">Nuevo Usuario</h2>
          <form onSubmit={handleCrear} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Nombre *</label>
              <input type="text" name="nombre" value={form.nombre} onChange={handleChange} required placeholder="Juan"
                className="w-full px-3 py-2 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Apellido *</label>
              <input type="text" name="apellido" value={form.apellido} onChange={handleChange} required placeholder="Pérez"
                className="w-full px-3 py-2 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Email *</label>
              <input type="email" name="email" value={form.email} onChange={handleChange} required placeholder="juan@mimos.co"
                className="w-full px-3 py-2 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Contraseña *</label>
              <input type="password" name="password" value={form.password} onChange={handleChange} required placeholder="••••••••"
                className="w-full px-3 py-2 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">ID Rol *</label>
              <input type="number" name="idRol" value={form.idRol} onChange={handleChange} required placeholder="Ej. 1 (Admin) o 2 (Cliente)"
                className="w-full px-3 py-2 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div className="flex items-end pt-2">
              <button type="submit" disabled={creando}
                className="w-full px-6 py-2.5 rounded-lg bg-[var(--color-acento)] text-white text-sm font-bold hover:bg-orange-600 disabled:opacity-50 transition-colors shadow-sm">
                {creando ? "Registrando..." : "Registrar Usuario"}
              </button>
            </div>
          </form>
        </div>

        {/* Tabla */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-[var(--color-borde)] bg-[var(--color-fondo)]">
            <h2 className="text-sm font-bold text-[var(--color-texto)] uppercase tracking-wider">Usuarios Registrados</h2>
          </div>
          {cargando ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm animate-pulse">Sincronizando base de datos...</div>
          ) : usuarios.length === 0 ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm font-bold">No hay usuarios registrados.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-[var(--color-secundario-soft)]">
                  <tr>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">ID</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Nombre Completo</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Email</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Rol</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Estado</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Registro</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase text-center">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--color-borde)]">
                  {usuarios.map((u) => (
                    <tr key={u.idUsuario} className="hover:bg-[var(--color-fondo)] transition-colors">
                      <td className="px-5 py-3 font-mono text-gray-500">#{u.idUsuario}</td>
                      <td className="px-5 py-3 font-bold text-[var(--color-texto)]">{u.nombre} {u.apellido}</td>
                      <td className="px-5 py-3 text-[var(--color-texto-suave)]">{u.email}</td>
                      <td className="px-5 py-3">
                        <span className="px-2 py-1 rounded-md text-xs font-black bg-[var(--color-secundario-soft)] text-[var(--color-acento)]">
                          {u.rol ?? "—"}
                        </span>
                      </td>
                      <td className="px-5 py-3">
                        <span className={`px-2 py-1 rounded-md text-xs font-bold ${u.estado === 'activo' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
                          {u.estado ?? "—"}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-[var(--color-texto-suave)] font-medium">
                        {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : "—"}
                      </td>
                      <td className="px-5 py-3 text-center">
                        <button onClick={() => handleEliminar(u.idUsuario)}
                          className="px-3 py-1 rounded-lg border border-red-300 text-red-600 text-xs font-bold hover:bg-red-50 transition-colors">
                          Eliminar
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}