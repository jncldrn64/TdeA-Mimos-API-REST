import { useState, useEffect } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8081";

const getHeaders = () => {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

const ESTADOS_PQRS = ["abierto", "en proceso", "cerrado"];

export default function GestionPQRS() {
  const [pqrsList, setPqrsList] = useState([]);
  const [cargando, setCargando] = useState(false);
  const [creando, setCreando] = useState(false);
  const [error, setError] = useState("");
  const [filtroEstado, setFiltroEstado] = useState("");
  const [form, setForm] = useState({
    usuarioId: "",
    ventaId: "",
    asunto: "",
    mensaje: "",
  });

  const cargarPQRS = async (estado = "") => {
    setCargando(true);
    setError("");
    try {
      const url = estado
        ? `${API}/api/pqrs/estado/${encodeURIComponent(estado)}`
        : `${API}/api/pqrs`;
      const res = await fetch(url, { headers: getHeaders() });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      setPqrsList(await res.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
    }
  };

  useEffect(() => { cargarPQRS(); }, []);

  const handleFiltro = (e) => {
    const val = e.target.value;
    setFiltroEstado(val);
    cargarPQRS(val);
  };

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleCrear = async (e) => {
    e.preventDefault();
    setCreando(true);
    setError("");
    try {
      // Mapeo exacto esperado por CrearPQRSDTO
      const body = {
        usuarioId: Number(form.usuarioId),
        ventaId: form.ventaId ? Number(form.ventaId) : null,
        asunto: form.asunto,
        mensaje: form.mensaje,
      };
      
      const res = await fetch(`${API}/api/pqrs`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(body),
      });
      
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || `Error ${res.status}`);
      }
      
      setForm({ usuarioId: "", ventaId: "", asunto: "", mensaje: "" });
      await cargarPQRS(filtroEstado);
    } catch (e) {
      setError(e.message);
    } finally {
      setCreando(false);
    }
  };

  const handleEliminar = async (idPqrs) => {
    if (!window.confirm(`¿Eliminar el registro de PQRS #${idPqrs}?`)) return;
    setError("");
    try {
      const res = await fetch(`${API}/api/pqrs/${idPqrs}`, {
        method: "DELETE",
        headers: getHeaders(),
      });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      await cargarPQRS(filtroEstado);
    } catch (e) {
      setError(e.message);
    }
  };

  const estadoBadge = (estado) => {
    const map = {
      abierto: "bg-red-100 text-red-700",
      "en proceso": "bg-yellow-100 text-yellow-700",
      cerrado: "bg-green-100 text-green-700",
    };
    return map[estado?.toLowerCase()] ?? "bg-[var(--color-secundario-soft)] text-[var(--color-acento)]";
  };

  return (
    <div className="min-h-screen bg-[var(--color-fondo)] p-6 font-inherit">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-2xl font-black text-[var(--color-texto)] mb-6 tracking-tight">
          Gestión de PQRS
        </h1>

        {error && (
          <div className="mb-4 p-3 rounded-lg border border-red-400 bg-red-50 text-red-700 text-sm font-bold">
            {error}
          </div>
        )}

        {/* Formulario */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl p-6 mb-6 shadow-sm">
          <h2 className="text-sm font-bold text-[var(--color-texto)] mb-4 uppercase tracking-wider">Registrar Ticket Manual</h2>
          <form onSubmit={handleCrear} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">ID Usuario *</label>
              <input type="number" name="usuarioId" value={form.usuarioId} onChange={handleChange} required placeholder="Ej. 1"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">
                ID Venta <span className="text-[var(--color-texto-suave)] font-normal">(Opcional)</span>
              </label>
              <input type="number" name="ventaId" value={form.ventaId} onChange={handleChange} placeholder="Ej. 3"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Asunto *</label>
              <input type="text" name="asunto" value={form.asunto} onChange={handleChange} required placeholder="Resumen del problema..."
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Mensaje Detallado *</label>
              <textarea name="mensaje" value={form.mensaje} onChange={handleChange} required rows={3}
                placeholder="Describa detalladamente la solicitud..."
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)] resize-none" />
            </div>
            <div className="sm:col-span-2 flex justify-end mt-2">
              <button type="submit" disabled={creando}
                className="px-8 py-2.5 rounded-lg bg-[var(--color-acento)] text-white text-sm font-bold hover:bg-orange-600 disabled:opacity-50 transition-colors shadow-sm">
                {creando ? "Enviando..." : "Crear PQRS"}
              </button>
            </div>
          </form>
        </div>

        {/* Tabla */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-[var(--color-borde)] bg-[var(--color-fondo)] flex items-center justify-between gap-4 flex-wrap">
            <h2 className="text-sm font-bold text-[var(--color-texto)] uppercase tracking-wider">Tickets de Soporte</h2>
            <select value={filtroEstado} onChange={handleFiltro}
              className="px-3 py-1.5 rounded-lg border border-[var(--color-borde)] bg-white text-[var(--color-texto)] text-sm font-bold focus:outline-none focus:border-[var(--color-acento)] shadow-sm cursor-pointer">
              <option value="">Todos los estados</option>
              {ESTADOS_PQRS.map((e) => <option key={e} value={e}>{e.toUpperCase()}</option>)}
            </select>
          </div>
          {cargando ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm animate-pulse">Sincronizando buzón...</div>
          ) : pqrsList.length === 0 ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm font-bold">No hay tickets registrados.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-[var(--color-secundario-soft)]">
                  <tr>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Ticket</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Usuario</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Venta</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Asunto / Mensaje</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Estado</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Fecha</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase text-center">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--color-borde)]">
                  {pqrsList.map((p) => (
                    <tr key={p.idPqrs} className="hover:bg-[var(--color-fondo)] transition-colors">
                      <td className="px-5 py-3 font-mono text-gray-500">#{p.idPqrs}</td>
                      <td className="px-5 py-3 font-bold text-[var(--color-texto)]">Usu. #{p.usuarioId}</td>
                      <td className="px-5 py-3 text-[var(--color-texto-suave)]">{p.ventaId ? `Venta #${p.ventaId}` : "—"}</td>
                      <td className="px-5 py-3">
                        <p className="font-bold text-[var(--color-texto)] truncate max-w-[200px]" title={p.asunto}>{p.asunto}</p>
                        <p className="text-xs text-[var(--color-texto-suave)] truncate max-w-[200px] mt-1" title={p.mensaje}>{p.mensaje}</p>
                      </td>
                      <td className="px-5 py-3">
                        <span className={`px-2 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${estadoBadge(p.estado)}`}>
                          {p.estado ?? "—"}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-[var(--color-texto-suave)] font-medium">
                        {p.fechaCreacion ? new Date(p.fechaCreacion).toLocaleDateString() : "—"}
                      </td>
                      <td className="px-5 py-3 text-center">
                        <button onClick={() => handleEliminar(p.idPqrs)}
                          className="px-3 py-1 rounded-lg border border-red-300 text-red-600 text-xs font-bold hover:bg-red-50 transition-colors">
                          Eliminar
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}