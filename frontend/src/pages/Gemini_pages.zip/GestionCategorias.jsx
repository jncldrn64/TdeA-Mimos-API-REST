import { useState, useEffect } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8081";

const getHeaders = () => {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

export default function GestionCategorias() {
  const [categorias, setCategorias] = useState([]);
  const [cargando, setCargando] = useState(false);
  const [creando, setCreando] = useState(false);
  const [error, setError] = useState("");
  
  // Estado para el formulario de Creación
  const [form, setForm] = useState({ nombre: "", descripcion: "" });
  
  // Estado para el Modal de Edición (PUT)
  const [modalEdicion, setModalEdicion] = useState(null);
  const [actualizando, setActualizando] = useState(false);

  const cargarCategorias = async () => {
    setCargando(true);
    setError("");
    try {
      const res = await fetch(`${API}/api/categorias`, { headers: getHeaders() });
      if (!res.ok) throw new Error(`Error al cargar: ${res.status}`);
      setCategorias(await res.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
    }
  };

  useEffect(() => { cargarCategorias(); }, []);

  // ── MÉTODOS POST (Crear) ──
  const handleCrear = async (e) => {
    e.preventDefault();
    setCreando(true);
    setError("");
    try {
      const res = await fetch(`${API}/api/categorias`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error(`Error al crear: ${res.status}`);
      setForm({ nombre: "", descripcion: "" });
      await cargarCategorias();
    } catch (e) {
      setError(e.message);
    } finally {
      setCreando(false);
    }
  };

  // ── MÉTODOS PUT (Actualizar) ──
  const handleActualizar = async (e) => {
    e.preventDefault();
    setActualizando(true);
    try {
      const res = await fetch(`${API}/api/categorias/${modalEdicion.idCategoria}`, {
        method: "PUT",
        headers: getHeaders(),
        body: JSON.stringify({
          nombre: modalEdicion.nombre,
          descripcion: modalEdicion.descripcion
        }),
      });
      if (!res.ok) throw new Error(`Error al actualizar: ${res.status}`);
      setModalEdicion(null);
      await cargarCategorias();
    } catch (e) {
      alert(e.message);
    } finally {
      setActualizando(false);
    }
  };

  // ── MÉTODO DELETE (Eliminar) ──
  const handleEliminar = async (id) => {
    if (!window.confirm(`¿Estás seguro de eliminar la categoría #${id}? (Asegúrate de que no tenga productos)`)) return;
    setError("");
    try {
      const res = await fetch(`${API}/api/categorias/${id}`, {
        method: "DELETE",
        headers: getHeaders(),
      });
      if (!res.ok) throw new Error(`Error al eliminar: ${res.status}`);
      await cargarCategorias();
    } catch (e) {
      setError(e.message);
    }
  };

  return (
    <div className="min-h-screen bg-[var(--color-fondo)] p-6 font-inherit">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-2xl font-black text-[var(--color-texto)] mb-6 tracking-tight">
          Gestión de Categorías
        </h1>

        {error && (
          <div className="mb-4 p-3 rounded-lg border border-red-400 bg-red-50 text-red-700 text-sm font-bold">
            {error}
          </div>
        )}

        {/* Formulario Crear */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl p-5 mb-6 shadow-sm">
          <h2 className="text-sm font-bold text-[var(--color-texto)] mb-4 uppercase tracking-wider">Nueva Categoría</h2>
          <form onSubmit={handleCrear} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Nombre *</label>
              <input type="text" value={form.nombre} onChange={e => setForm({...form, nombre: e.target.value})} required placeholder="Ej. Helados"
                className="w-full px-3 py-2 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Descripción</label>
              <input type="text" value={form.descripcion} onChange={e => setForm({...form, descripcion: e.target.value})} placeholder="Descripción opcional"
                className="w-full px-3 py-2 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div className="sm:col-span-2 flex justify-end">
              <button type="submit" disabled={creando}
                className="px-6 py-2.5 rounded-lg bg-[var(--color-acento)] text-white text-sm font-bold hover:bg-orange-600 disabled:opacity-50 transition-colors shadow-sm">
                {creando ? "Creando..." : "Crear Categoría"}
              </button>
            </div>
          </form>
        </div>

        {/* Tabla */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-[var(--color-borde)] bg-[var(--color-fondo)]">
            <h2 className="text-sm font-bold text-[var(--color-texto)] uppercase tracking-wider">Catálogo de Categorías</h2>
          </div>
          {cargando ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm animate-pulse">Sincronizando base de datos...</div>
          ) : categorias.length === 0 ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm font-bold">No hay categorías registradas.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-[var(--color-secundario-soft)]">
                  <tr>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">ID</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Nombre</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Descripción</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase text-center">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--color-borde)]">
                  {categorias.map((cat) => (
                    <tr key={cat.idCategoria} className="hover:bg-[var(--color-fondo)] transition-colors">
                      <td className="px-5 py-3 font-mono text-gray-500">#{cat.idCategoria}</td>
                      <td className="px-5 py-3 font-bold text-[var(--color-texto)]">{cat.nombre}</td>
                      <td className="px-5 py-3 text-[var(--color-texto-suave)]">{cat.descripcion ?? "—"}</td>
                      <td className="px-5 py-3 text-center">
                        <button onClick={() => setModalEdicion({...cat})} className="text-[var(--color-acento)] hover:text-orange-700 font-bold text-xs mr-4 hover:underline">Editar</button>
                        <button onClick={() => handleEliminar(cat.idCategoria)} className="text-red-500 hover:text-red-700 font-bold text-xs hover:underline">Eliminar</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* ── MODAL FLOTANTE DE EDICIÓN ── */}
        {modalEdicion && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-200">
             <div className="bg-[var(--color-superficie)] w-full max-w-md rounded-2xl shadow-2xl p-6 border border-[var(--color-borde)]">
                <h3 className="text-lg font-black mb-4 border-b border-[var(--color-borde)] pb-3 text-[var(--color-texto)]">
                  Modificar Categoría #{modalEdicion.idCategoria}
                </h3>
                <form onSubmit={handleActualizar} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Nombre *</label>
                    <input type="text" required value={modalEdicion.nombre} onChange={e => setModalEdicion({...modalEdicion, nombre: e.target.value})}
                      className="w-full p-2.5 border border-[var(--color-borde)] rounded-lg bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Descripción</label>
                    <input type="text" value={modalEdicion.descripcion} onChange={e => setModalEdicion({...modalEdicion, descripcion: e.target.value})}
                      className="w-full p-2.5 border border-[var(--color-borde)] rounded-lg bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
                  </div>
                  <div className="flex gap-3 mt-6 pt-4 border-t border-[var(--color-borde)]">
                    <button type="button" onClick={() => setModalEdicion(null)} className="flex-1 bg-[var(--color-fondo)] border border-[var(--color-borde)] text-[var(--color-texto-suave)] font-bold py-2.5 rounded-lg hover:bg-gray-100 transition-colors">Cancelar</button>
                    <button type="submit" disabled={actualizando} className="flex-1 bg-[var(--color-acento)] text-white font-bold py-2.5 rounded-lg hover:bg-orange-600 disabled:opacity-50 transition-colors shadow-sm">
                      {actualizando ? "Guardando..." : "Guardar Cambios"}
                    </button>
                  </div>
                </form>
             </div>
          </div>
        )}

      </div>
    </div>
  );
}