import { useState } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8081";

const getHeaders = () => {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

export default function GestionCarritoItems() {
  const [items, setItems] = useState([]);
  const [cargando, setCargando] = useState(false);
  const [creando, setCreando] = useState(false);
  const [error, setError] = useState("");
  const [idCarritoBuscar, setIdCarritoBuscar] = useState("");
  
  const [form, setForm] = useState({
    carritoId: "",
    productoId: "",
    cantidad: "",
    precioSnapshot: "",
  });

  const cargarItems = async (idCarrito) => {
    if (!idCarrito) return;
    setCargando(true);
    setError("");
    try {
      const res = await fetch(`${API}/api/carrito-items/carrito/${idCarrito}`, {
        headers: getHeaders(),
      });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      setItems(await res.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
    }
  };

  const handleBuscar = (e) => {
    e.preventDefault();
    cargarItems(idCarritoBuscar);
  };

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleCrear = async (e) => {
    e.preventDefault();
    setCreando(true);
    setError("");
    try {
      // El controlador espera un CarritoItem (Entity)
      const body = {
        carrito: { idCarrito: Number(form.carritoId) },
        producto: { idProducto: Number(form.productoId) },
        cantidad: Number(form.cantidad),
        precioSnapshot: parseFloat(form.precioSnapshot),
      };

      const res = await fetch(`${API}/api/carrito-items`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || `Error ${res.status}`);
      }
      
      setForm({ carritoId: "", productoId: "", cantidad: "", precioSnapshot: "" });
      await cargarItems(idCarritoBuscar || form.carritoId);
    } catch (e) {
      setError(e.message);
    } finally {
      setCreando(false);
    }
  };

  const handleEliminar = async (idItem) => {
    if (!window.confirm(`¿Eliminar ítem #${idItem} del carrito?`)) return;
    setError("");
    try {
      const res = await fetch(`${API}/api/carrito-items/${idItem}`, {
        method: "DELETE",
        headers: getHeaders(),
      });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      setItems((prev) => prev.filter((i) => i.idItem !== idItem));
    } catch (e) {
      setError(e.message);
    }
  };

  return (
    <div className="min-h-screen bg-[var(--color-fondo)] p-6 font-inherit">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-2xl font-black text-[var(--color-texto)] mb-6 tracking-tight">
          Gestión de Ítems de Carrito
        </h1>

        {error && (
          <div className="mb-4 p-3 rounded-lg border border-red-400 bg-red-50 text-red-700 text-sm font-bold">
            {error}
          </div>
        )}

        {/* Buscador por carrito */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl p-6 mb-6 shadow-sm">
          <h2 className="text-sm font-bold text-[var(--color-texto)] mb-3 uppercase tracking-wider">
            Buscar Ítems
          </h2>
          <form onSubmit={handleBuscar} className="flex gap-4">
            <input
              type="number"
              value={idCarritoBuscar}
              onChange={(e) => setIdCarritoBuscar(e.target.value)}
              placeholder="Ingresa el ID del carrito..."
              required
              className="flex-1 px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]"
            />
            <button
              type="submit"
              className="px-8 py-2.5 rounded-lg bg-[var(--color-primario)] text-white text-sm font-bold hover:bg-[var(--color-primario-dark)] transition-colors shadow-sm"
            >
              Buscar
            </button>
          </form>
        </div>

        {/* Formulario Crear */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl p-6 mb-6 shadow-sm">
          <h2 className="text-sm font-bold text-[var(--color-texto)] mb-4 uppercase tracking-wider">
            Agregar Ítem a un Carrito
          </h2>
          <form onSubmit={handleCrear} className="grid grid-cols-1 sm:grid-cols-4 gap-4 items-end">
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">ID Carrito *</label>
              <input type="number" name="carritoId" value={form.carritoId} onChange={handleChange} required placeholder="Ej. 1"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">ID Producto *</label>
              <input type="number" name="productoId" value={form.productoId} onChange={handleChange} required placeholder="Ej. 5"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Cantidad *</label>
              <input type="number" name="cantidad" value={form.cantidad} onChange={handleChange} required placeholder="Ej. 2"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            <div>
              <label className="block text-xs font-bold text-[var(--color-texto-suave)] mb-1 uppercase">Precio Snapshot *</label>
              <input type="number" step="0.01" name="precioSnapshot" value={form.precioSnapshot} onChange={handleChange} required placeholder="Ej. 8500.00"
                className="w-full px-3 py-2.5 rounded-lg border border-[var(--color-borde)] bg-[var(--color-fondo)] text-sm focus:outline-none focus:border-[var(--color-acento)]" />
            </div>
            
            <div className="sm:col-span-4 flex justify-end mt-2">
              <button
                type="submit"
                disabled={creando}
                className="px-8 py-2.5 rounded-lg bg-[var(--color-acento)] text-white text-sm font-bold hover:bg-orange-600 disabled:opacity-50 transition-colors shadow-sm"
              >
                {creando ? "Agregando..." : "Agregar Ítem"}
              </button>
            </div>
          </form>
        </div>

        {/* Tabla */}
        <div className="bg-[var(--color-superficie)] border border-[var(--color-borde)] rounded-xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-[var(--color-borde)] bg-[var(--color-fondo)]">
            <h2 className="text-sm font-bold text-[var(--color-texto)] uppercase tracking-wider">
              Contenido del Carrito #{idCarritoBuscar || "..."}
            </h2>
          </div>
          {cargando ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm animate-pulse">Sincronizando...</div>
          ) : items.length === 0 ? (
            <div className="p-8 text-center text-[var(--color-texto-suave)] text-sm font-bold">
              Busca un carrito o agrega ítems para visualizarlos aquí.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-[var(--color-secundario-soft)]">
                  <tr>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">ID Ítem</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Producto</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Cantidad</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Precio Congelado</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase">Subtotal</th>
                    <th className="px-5 py-3 text-xs font-bold text-[var(--color-texto-suave)] uppercase text-center">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--color-borde)]">
                  {items.map((item) => (
                    <tr key={item.idItem} className="hover:bg-[var(--color-fondo)] transition-colors">
                      <td className="px-5 py-3 font-mono text-gray-500">#{item.idItem}</td>
                      <td className="px-5 py-3 font-bold text-[var(--color-texto)]">Prod. #{item.idProducto}</td>
                      <td className="px-5 py-3 font-medium text-[var(--color-texto)]">{item.cantidad}</td>
                      <td className="px-5 py-3 text-[var(--color-texto-suave)] font-medium">
                        ${item.precioSnapshot != null ? item.precioSnapshot.toLocaleString() : "—"}
                      </td>
                      <td className="px-5 py-3 text-[var(--color-acento)] font-black">
                        ${(item.cantidad * item.precioSnapshot).toLocaleString()}
                      </td>
                      <td className="px-5 py-3 text-center">
                        <button
                          onClick={() => handleEliminar(item.idItem)}
                          className="px-3 py-1 rounded-lg border border-red-300 text-red-600 text-xs font-bold hover:bg-red-50 transition-colors"
                        >
                          Eliminar
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}